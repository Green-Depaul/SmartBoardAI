import React, { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { ScrollArea } from "./ui/scroll-area";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ArrowLeft, Send, Bot, User, LayoutGrid, Clock, Plus, FolderOpen, X, CheckCircle } from "lucide-react";
import { api, type AIResponse, type TaskSuggestion, type Project } from "../services/api";

interface ChatPageProps {
  onNavigateBack: () => void;
  onNavigateToKanban: (projectId?: string) => void;
  currentUser?: { id: number; email: string; firstName: string; lastName: string };
  messages: Message[];
  setMessages: React.Dispatch<React.SetStateAction<Message[]>>;
}

export interface Message {
  id: string;
  text: string;
  sender: "user" | "ai";
  timestamp: Date;
  aiResponse?: AIResponse;
}

export function ChatPage({ onNavigateBack, onNavigateToKanban, currentUser, messages, setMessages }: ChatPageProps) {
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loadingProjects, setLoadingProjects] = useState(false);
  const [creatingProject, setCreatingProject] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load projects when component mounts
  useEffect(() => {
    if (currentUser) {
      loadProjects();
    }
  }, [currentUser]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const loadProjects = async () => {
    if (!currentUser) return;
    
    try {
      setLoadingProjects(true);
      console.log("Loading projects for user:", currentUser.id);
      const userProjects = await api.getProjects(currentUser.id);
      console.log("Projects loaded:", userProjects);
      setProjects(userProjects);
    } catch (err) {
      console.error("Error loading projects:", err);
    } finally {
      setLoadingProjects(false);
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isTyping) return;
    if (!currentUser) {
      setError("Please log in to start a project");
      return;
    }

    const projectDescription = inputValue.trim();
    const userMessage: Message = {
      id: Date.now().toString(),
      text: projectDescription,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);
    setError(null);

    try {
      const aiResponse = await api.generatePlan(projectDescription);
      
      // Show AI response
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse.message,
        sender: "ai",
        timestamp: new Date(),
        aiResponse: aiResponse,
      };
      
      setMessages((prev) => [...prev, aiMessage]);
      
      // Create project automatically with all AI tasks
      await createProjectFromAIResponse(projectDescription, aiResponse);
      
    } catch (err) {
      console.error("Error calling AI service:", err);
      setError("Sorry, I couldn't process your request. Please try again.");
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "Sorry, I encountered an error while processing your request. Please try again.",
        sender: "ai",
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const createProjectFromAIResponse = async (description: string, aiResponse: AIResponse) => {
    if (!currentUser) return;

    setCreatingProject(true);
    try {
      // Create a title from first few words of description
      const title = description.split(' ').slice(0, 5).join(' ') || "New Project";
      
      console.log("Creating project:", { title, userId: currentUser.id.toString() });
      const newProject = await api.createProjectFromAI({
        title,
        description: description,
        userId: currentUser.id.toString(),
        suggestions: aiResponse.suggestedTasks
      });
      console.log("Project created:", newProject);

      // Reload projects list
      console.log("Reloading projects...");
      await loadProjects();
      console.log("Projects reloaded");

      // Show success message
      const successMessage: Message = {
        id: `success-${Date.now()}`,
        text: `✅ Project "${title}" created with ${aiResponse.suggestedTasks.length} tasks! Click on the project above to view it.`,
        sender: "ai",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, successMessage]);

    } catch (err) {
      console.error("Error creating project:", err);
      setError("Failed to create project. Please try again.");
    } finally {
      setCreatingProject(false);
    }
  };

  const handleDeleteProject = async (projectId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this project?")) {
      try {
        await api.deleteProject(projectId);
        await loadProjects();
      } catch (err) {
        console.error("Error deleting project:", err);
      }
    }
  };

  const handleOpenProject = (projectId: string) => {
    // Navigate to Kanban board with this specific project
    onNavigateToKanban(projectId);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Header */}
      <header className="flex items-center justify-between gap-4 px-4 py-4 border-b bg-card">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onNavigateBack}
            className="shrink-0"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-full">
              <Bot className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg">Smart Board AI</h2>
              <p className="text-sm text-muted-foreground">
                Your AI project assistant
              </p>
            </div>
          </div>
        </div>
        <Button
          onClick={onNavigateToKanban}
          className="shrink-0 bg-[#2563eb] hover:bg-[#1e40af]"
        >
          <LayoutGrid className="h-4 w-4 mr-2" />
          View Board
        </Button>
      </header>

      {/* Projects List */}
      <div className="border-b bg-muted/30">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <FolderOpen className="h-4 w-4" />
              Your Projects
            </h3>
            <Badge variant="secondary">{projects.length} project{projects.length !== 1 ? 's' : ''}</Badge>
          </div>
          
          <ScrollArea className="max-h-20">
            {loadingProjects ? (
              <p className="text-xs text-muted-foreground">Loading projects...</p>
            ) : projects.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">No projects yet. Start your first project below!</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {projects.map((project) => (
                  <div key={project.id} className="group relative">
                    <Badge className="pr-6 cursor-pointer hover:bg-primary/20" variant="outline" onClick={() => handleOpenProject(project.id)}>
                      {project.title}
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full p-0 hover:bg-destructive/20"
                        onClick={(e) => handleDeleteProject(project.id, e)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </div>

      {/* Main Content Area - Split into Chat and Input */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Chat Messages Area - Fixed height at bottom */}
        <div className="flex-1 min-h-0 px-4 py-4">
          <ScrollArea className="h-full">
            <div className="max-w-4xl mx-auto space-y-6">
              {/* Welcome message if no messages */}
              {messages.length === 0 && (
                <div className="text-center py-12">
                  <Bot className="h-12 w-12 mx-auto mb-4 text-primary opacity-50" />
                  <h3 className="text-lg font-semibold mb-2">Start a New Project</h3>
                  <p className="text-sm text-muted-foreground">
                    Describe your project idea and I'll create a plan with tasks for you!
                  </p>
                </div>
              )}

              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${
                    message.sender === "user" ? "flex-row-reverse" : "flex-row"
                  }`}
                >
                  {/* Avatar */}
                  <div
                className={`shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                  message.sender === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground"
                }`}
              >
                {message.sender === "user" ? (
                  <User className="h-4 w-4" />
                ) : (
                  <Bot className="h-4 w-4" />
                )}
              </div>

                  {/* Message Bubble */}
                  <div
                className={`flex flex-col gap-1 max-w-[80%] md:max-w-[70%] ${
                  message.sender === "user" ? "items-end" : "items-start"
                }`}
              >
                <div
                  className={`px-4 py-3 rounded-2xl ${
                    message.sender === "user"
                      ? "bg-primary text-primary-foreground rounded-tr-sm"
                      : "bg-secondary text-secondary-foreground rounded-tl-sm"
                  }`}
                >
                  <p className="break-words">{message.text}</p>
                  
                  {/* Display AI Response with structured plan */}
                  {message.aiResponse && (
                    <div className="mt-4 space-y-3">
                      {message.aiResponse.plan && (
                        <div className="bg-white/10 rounded-lg p-3">
                          <h3 className="font-semibold mb-2 text-sm">📋 Plan Summary</h3>
                          <pre className="text-xs whitespace-pre-wrap font-mono leading-relaxed">
                            {message.aiResponse.plan}
                          </pre>
                        </div>
                      )}
                      
                      {message.aiResponse.suggestedTasks && message.aiResponse.suggestedTasks.length > 0 && (
                        <div className="bg-white/10 rounded-lg p-3">
                          <h3 className="font-semibold mb-2 text-sm">
                            ✅ {message.aiResponse.suggestedTasks.length} Tasks Created
                          </h3>
                          <div className="space-y-1">
                            {message.aiResponse.suggestedTasks.slice(0, 3).map((task, index) => (
                              <div key={index} className="flex items-center gap-2 text-xs">
                                <CheckCircle className="h-3 w-3" />
                                <span className="truncate">{task.title}</span>
                                <span className="text-muted-foreground">
                                  {task.estimatedHours}h
                                </span>
                              </div>
                            ))}
                            {message.aiResponse.suggestedTasks.length > 3 && (
                              <p className="text-xs text-muted-foreground">
                                +{message.aiResponse.suggestedTasks.length - 3} more tasks
                              </p>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
                <span className="text-xs text-muted-foreground px-2">
                  {message.timestamp.toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
            </div>
          ))}

              {/* Typing Indicator */}
              {isTyping && (
                <div className="flex gap-3">
                  <div className="shrink-0 h-8 w-8 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center">
                <Bot className="h-4 w-4" />
              </div>
              <div className="bg-secondary text-secondary-foreground px-4 py-3 rounded-2xl rounded-tl-sm">
                <div className="flex gap-1">
                  <span
                    className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce"
                    style={{ animationDelay: "0ms" }}
                  ></span>
                  <span
                    className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce"
                    style={{ animationDelay: "150ms" }}
                  ></span>
                  <span
                    className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce"
                    style={{ animationDelay: "300ms" }}
                  ></span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
        </div>
        </div>

      {/* Input Area */}
      <div className="border-t bg-card">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex gap-2">
            <Input
              type="text"
              placeholder="Describe your project idea (e.g., 'Build a mobile app for food delivery')..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={isTyping || creatingProject}
              className="flex-1 bg-input-background border-border"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isTyping || creatingProject}
              size="icon"
              className="shrink-0"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2 text-center">
            Press Enter to create a new project with AI-generated tasks
          </p>
          {creatingProject && (
            <p className="text-xs text-primary mt-2 text-center animate-pulse">
              Creating your project...
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
