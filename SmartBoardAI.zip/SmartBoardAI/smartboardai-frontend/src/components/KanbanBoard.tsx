import { useState, useEffect } from "react";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { ArrowLeft, Plus, MoreVertical, Clock, User, RefreshCw, MessageSquare, X, Bot, ChevronDown } from "lucide-react";
import { ScrollArea } from "./ui/scroll-area";
import { api, type Task as APITask } from "../services/api";

interface KanbanBoardProps {
  onNavigateBack: () => void;
  currentUser?: { id: number; email: string; firstName: string; lastName: string };
  projectId?: string; // Project/Board ID to filter tasks
}

export type TaskStatus = "TODO" | "IN_PROGRESS" | "IN_REVIEW" | "DONE";

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: TaskStatus;
  priority?: "LOW" | "MEDIUM" | "HIGH" | "URGENT";
  estimatedHours?: number;
  createdAt?: string;
  boardId?: string;
}

const ITEM_TYPE = "TASK";

// Convert API task to local task format
const convertAPITaskToLocal = (apiTask: any): Task => ({
  id: apiTask.id.toString(),
  title: apiTask.title,
  description: apiTask.description,
  status: apiTask.status as TaskStatus,
  priority: apiTask.priority,
  estimatedHours: apiTask.estimatedHours,
  createdAt: apiTask.createdAt,
  boardId: apiTask.boardId, // Include boardId for filtering
});

const columns: { id: TaskStatus; title: string; color: string }[] = [
  { id: "TODO", title: "To Do", color: "bg-gray-100" },
  { id: "IN_PROGRESS", title: "In Progress", color: "bg-blue-100" },
  { id: "IN_REVIEW", title: "In Review", color: "bg-yellow-100" },
  { id: "DONE", title: "Done", color: "bg-green-100" },
];

const getPriorityColor = (priority?: string) => {
  switch (priority) {
    case "URGENT":
      return "bg-red-500 text-white";
    case "HIGH":
      return "bg-orange-500 text-white";
    case "MEDIUM":
      return "bg-yellow-500 text-black";
    case "LOW":
      return "bg-green-500 text-white";
    default:
      return "bg-gray-500 text-white";
  }
};

const getPriorityLabel = (priority?: string) => {
  switch (priority) {
    case "URGENT":
      return "Urgent";
    case "HIGH":
      return "High";
    case "MEDIUM":
      return "Medium";
    case "LOW":
      return "Low";
    default:
      return "Medium";
  }
};

interface TaskCardProps {
  task: Task;
  onMoveTask: (taskId: string, newStatus: TaskStatus) => void;
}

function TaskCard({ task, onMoveTask }: TaskCardProps) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: ITEM_TYPE,
    item: { id: task.id, status: task.status },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));

  return (
    <div
      ref={drag}
      className={`mb-3 cursor-move ${isDragging ? "opacity-50" : ""}`}
    >
      <Card className="p-3 hover:shadow-md transition-shadow">
        <div className="flex items-start justify-between mb-2">
          <h4 className="font-medium text-sm leading-tight">{task.title}</h4>
          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
            <MoreVertical className="h-3 w-3" />
          </Button>
        </div>
        
        {task.description && (
          <p className="text-xs text-gray-600 mb-2 line-clamp-2">
            {task.description}
          </p>
        )}
        
        <div className="flex items-center justify-between">
          <Badge
            className={`text-xs ${getPriorityColor(task.priority)}`}
            variant="secondary"
          >
            {getPriorityLabel(task.priority)}
          </Badge>
          
          {task.estimatedHours && (
            <div className="flex items-center text-xs text-gray-500">
              <Clock className="h-3 w-3 mr-1" />
              {task.estimatedHours}h
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}

interface TaskColumnProps {
  column: { id: TaskStatus; title: string; color: string };
  tasks: Task[];
  onMoveTask: (taskId: string, newStatus: TaskStatus) => void;
}

function TaskColumn({ column, tasks, onMoveTask }: TaskColumnProps) {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: ITEM_TYPE,
    drop: (item: { id: string; status: TaskStatus }) => {
      if (item.status !== column.id) {
        onMoveTask(item.id, column.id);
      }
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }));

  return (
    <div
      ref={drop}
      className={`flex-1 min-w-64 ${isOver ? "bg-blue-50" : ""}`}
    >
      <div className="bg-white rounded-lg shadow-sm border">
        <div className={`p-3 rounded-t-lg ${column.color}`}>
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-800">{column.title}</h3>
            <Badge variant="secondary" className="bg-white/80 text-gray-600">
              {tasks.length}
            </Badge>
          </div>
        </div>
        
        <ScrollArea className="h-96 p-3">
          {tasks.map((task) => (
            <TaskCard key={task.id} task={task} onMoveTask={onMoveTask} />
          ))}
          
          {tasks.length === 0 && (
            <div className="text-center text-gray-500 py-8">
              <p className="text-sm">No tasks</p>
            </div>
          )}
        </ScrollArea>
      </div>
    </div>
  );
}

export function KanbanBoard({ onNavigateBack, currentUser, projectId }: KanbanBoardProps) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<Array<{sender: string, text: string}>>([]);
  const [adjustingProject, setAdjustingProject] = useState(false);

  const fetchTasks = async () => {
    if (!currentUser) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      
      // If projectId is provided, fetch only tasks for that board
      let apiTasks: any[];
      if (projectId) {
        console.log('Fetching tasks for project/board:', projectId);
        // Fetch tasks for a specific board/project using the board API
        const boardResponse = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:8080'}/api/board/${projectId}`);
        if (!boardResponse.ok) {
          console.error('Board not found for ID:', projectId);
          throw new Error('Board not found');
        }
        const board = await boardResponse.json();
        console.log('Board data:', board);
        // Use tasks directly from the board response
        apiTasks = board.tasks || [];
        console.log('Tasks from board:', apiTasks);
      } else {
        // Fetch all tasks for the user
        console.log('Fetching all tasks for user:', currentUser.id);
        apiTasks = await api.getTasks(currentUser.id);
        console.log('All tasks:', apiTasks);
      }
      
      const localTasks = apiTasks.map(convertAPITaskToLocal);
      console.log('Converted local tasks:', localTasks);
      setTasks(localTasks);
      setError(null);
    } catch (err) {
      console.error("Error fetching tasks:", err);
      setError("Failed to load tasks. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [currentUser, projectId]);

  const handleMoveTask = async (taskId: string, newStatus: TaskStatus) => {
    try {
      await api.updateTaskStatus(parseInt(taskId), newStatus);
      
      // Update local state
      setTasks(prevTasks =>
        prevTasks.map(task =>
          task.id === taskId ? { ...task, status: newStatus } : task
        )
      );
    } catch (err) {
      console.error("Error updating task status:", err);
      setError("Failed to update task. Please try again.");
    }
  };

  const getTasksByStatus = (status: TaskStatus) => {
    return tasks.filter(task => task.status === status);
  };

  const handleAdjustProject = async () => {
    if (!chatInput.trim() || !currentUser) return;
    
    setAdjustingProject(true);
    const userMessage = chatInput;
    setChatInput("");
    
    // Do NOT add messages to chat - this keeps the chat box from growing
    
    try {
      // Prepare project data (tasks with current status)
      const projectData = {
        tasks: tasks,
        userId: currentUser.id
      };
      
      // Call adjustment API
      const response = await api.adjustProject(userMessage, projectData);
      
      // Update tasks if provided
      if (response.updatedTasks && response.updatedTasks.length > 0) {
        // Convert AI response tasks to local format, preserving ALL fields
        const updatedTasks = response.updatedTasks.map((task: any, index: number) => ({
          id: task.id?.toString() || String(task.id) || `temp-${index}-${Date.now()}`,
          title: task.title || '',
          description: task.description || '',
          status: task.status || 'TODO',
          priority: task.priority || 'MEDIUM',
          estimatedHours: task.estimatedHours || 0,
          createdAt: task.createdAt,
          boardId: task.boardId
        }));
        
        console.log('Updating Kanban board with tasks:', updatedTasks);
        
        // Update local state
        setTasks(updatedTasks);
        
        // Save updated tasks to database
        if (projectId) {
          try {
            console.log('Saving updated tasks to database for board:', projectId);
            await api.saveUpdatedTasks(updatedTasks, projectId);
            console.log('Tasks saved to database successfully');
            
            // Re-fetch tasks to get the real IDs from database
            console.log('Re-fetching tasks after save...');
            await fetchTasks();
            console.log('Tasks re-fetched successfully');
          } catch (err) {
            console.error('Error saving tasks to database:', err);
          }
        }
      }
      
    } catch (err) {
      console.error("Error adjusting project:", err);
    } finally {
      setAdjustingProject(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col h-screen bg-background">
        <header className="flex items-center justify-between gap-4 px-4 py-4 border-b bg-card">
          <Button variant="ghost" size="icon" onClick={onNavigateBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold">Kanban Board</h1>
          <div className="w-10" />
        </header>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-2 text-gray-500" />
            <p className="text-gray-600">Loading tasks...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="flex flex-col h-screen bg-background">
        <header className="flex items-center justify-between gap-4 px-4 py-4 border-b bg-card">
          <Button variant="ghost" size="icon" onClick={onNavigateBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold">Kanban Board</h1>
          <div className="w-10" />
        </header>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <p className="text-gray-600 mb-4">Please log in to view your Kanban board</p>
            <Button onClick={onNavigateBack}>Go Back</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-background relative">
      {/* Header */}
      <header className="flex items-center justify-between gap-4 px-4 py-4 border-b bg-card relative z-10">
        <Button variant="ghost" size="icon" onClick={onNavigateBack}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center gap-4">
          <h1 className="text-xl font-semibold">Kanban Board</h1>
          <Button
            variant="outline"
            size="sm"
            onClick={fetchTasks}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => setChatOpen(!chatOpen)}
            className={chatOpen ? "bg-primary text-primary-foreground" : ""}
          >
            <MessageSquare className="h-4 w-4 mr-2" />
            AI Assistant
          </Button>
        </div>
      </header>

      {/* Chat Box */}
      {chatOpen && (
        <div className="absolute top-16 left-4 w-96 h-[350px] bg-card border rounded-lg shadow-xl z-50 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b bg-muted/30 flex-shrink-0">
            <div className="flex items-center gap-2">
              <Bot className="h-5 w-5 text-primary" />
              <h3 className="font-semibold">Project AI Assistant</h3>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setChatOpen(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex-1 min-h-0 overflow-y-auto px-4 py-3">
            <div className="space-y-3 min-h-full">
              {/* Prompt instructions removed as requested */}
              
              {adjustingProject && (
                <div className="flex gap-2">
                  <Bot className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div className="bg-muted rounded-lg px-3 py-2 text-sm">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" />
                      <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" style={{animationDelay: "150ms"}} />
                      <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" style={{animationDelay: "300ms"}} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="border-t px-4 py-3 flex-shrink-0">
            <div className="flex gap-2">
              <Input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleAdjustProject();
                  }
                }}
                placeholder="Describe changes you want..."
                disabled={adjustingProject}
                className="flex-1"
              />
              <Button 
                onClick={handleAdjustProject}
                disabled={!chatInput.trim() || adjustingProject}
                size="icon"
              >
                <MessageSquare className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="mx-4 mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-700 text-sm">{error}</p>
        </div>
      )}

      {/* Kanban Board */}
      <div className="flex-1 overflow-hidden relative">
        <DndProvider backend={HTML5Backend}>
          <div className="flex gap-4 p-4 h-full overflow-x-auto">
            {columns.map((column) => (
              <TaskColumn
                key={column.id}
                column={column}
                tasks={getTasksByStatus(column.id)}
                onMoveTask={handleMoveTask}
              />
            ))}
          </div>
        </DndProvider>
      </div>
    </div>
  );
}