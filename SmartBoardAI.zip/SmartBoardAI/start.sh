#!/bin/bash

# SmartBoardAI Start Script for Linux/Mac

echo "🚀 Starting SmartBoardAI Application..."
echo ""

# Check if Java is installed
echo "Checking Java installation..."
if ! command -v java &> /dev/null; then
    echo "✗ Java not found. Please install Java 17 or later."
    exit 1
fi
echo "✓ Java found"

# Check if Node.js is installed
echo "Checking Node.js installation..."
if ! command -v node &> /dev/null; then
    echo "✗ Node.js not found. Please install Node.js 18 or later."
    exit 1
fi
echo "✓ Node.js found: $(node --version)"

echo ""
echo "Starting Backend (Spring Boot)..."
cd smartboard-api && ./mvnw spring-boot:run &
BACKEND_PID=$!

# Wait for backend to start
echo "Waiting for backend to start..."
sleep 10

echo ""
echo "Starting Frontend (React)..."
cd ../smartboardai-frontend && npm run dev &
FRONTEND_PID=$!

echo ""
echo "✓ Application started!"
echo ""
echo "Backend: http://localhost:8080"
echo "Frontend: http://localhost:3000"
echo ""
echo "Open http://localhost:3000 in your browser to start using the application."
echo ""
echo "To stop the services, press Ctrl+C and run: kill $BACKEND_PID $FRONTEND_PID"

# Wait for user to stop
wait

