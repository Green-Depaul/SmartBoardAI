package ai.smartboard.smartboard_api.repository;

import ai.smartboard.smartboard_api.model.Task;
import ai.smartboard.smartboard_api.model.TaskStatus;
import ai.smartboard.smartboard_api.model.TaskPriority;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for TaskRepository
 */
@DataJpaTest
class TaskRepositoryTest {
    
    @Autowired
    private TaskRepository taskRepository;
    
    @BeforeEach
    void setUp() {
        taskRepository.deleteAll();
    }
    
    @Test
    void testSaveAndFindTask() {
        Task task = new Task("Test Task", "Description");
        Task saved = taskRepository.save(task);
        
        assertNotNull(saved.getId());
        Optional<Task> found = taskRepository.findById(saved.getId());
        assertTrue(found.isPresent());
        assertEquals("Test Task", found.get().getTitle());
    }
    
    @Test
    void testFindByBoardId() {
        Task task1 = new Task("Task 1", "Description");
        task1.setBoardId("board1");
        Task task2 = new Task("Task 2", "Description");
        task2.setBoardId("board1");
        Task task3 = new Task("Task 3", "Description");
        task3.setBoardId("board2");
        
        taskRepository.save(task1);
        taskRepository.save(task2);
        taskRepository.save(task3);
        
        List<Task> board1Tasks = taskRepository.findByBoardId("board1");
        assertEquals(2, board1Tasks.size());
    }
    
    @Test
    void testFindByStatus() {
        Task task1 = new Task("Task 1", "Description", TaskStatus.TODO, TaskPriority.MEDIUM);
        Task task2 = new Task("Task 2", "Description", TaskStatus.DONE, TaskPriority.MEDIUM);
        
        taskRepository.save(task1);
        taskRepository.save(task2);
        
        List<Task> todoTasks = taskRepository.findByStatus(TaskStatus.TODO);
        assertEquals(1, todoTasks.size());
        assertEquals("Task 1", todoTasks.get(0).getTitle());
    }
    
    @Test
    void testDeleteTask() {
        Task task = new Task("Test Task", "Description");
        Task saved = taskRepository.save(task);
        
        assertTrue(taskRepository.existsById(saved.getId()));
        
        taskRepository.deleteById(saved.getId());
        assertFalse(taskRepository.existsById(saved.getId()));
    }
    
    @Test
    void testDeleteByBoardId() {
        Task task1 = new Task("Task 1", "Description");
        task1.setBoardId("board1");
        Task task2 = new Task("Task 2", "Description");
        task2.setBoardId("board1");
        
        taskRepository.save(task1);
        taskRepository.save(task2);
        
        taskRepository.deleteByBoardId("board1");
        assertEquals(0, taskRepository.countByBoardId("board1"));
    }
    
    @Test
    void testCountByBoardId() {
        Task task1 = new Task("Task 1", "Description");
        task1.setBoardId("board1");
        Task task2 = new Task("Task 2", "Description");
        task2.setBoardId("board1");
        
        taskRepository.save(task1);
        taskRepository.save(task2);
        
        assertEquals(2, taskRepository.countByBoardId("board1"));
    }
}

