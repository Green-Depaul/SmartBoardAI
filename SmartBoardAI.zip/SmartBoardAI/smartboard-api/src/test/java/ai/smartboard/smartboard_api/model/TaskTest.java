package ai.smartboard.smartboard_api.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Task model
 */
class TaskTest {
    
    @Test
    void testTaskCreation() {
        Task task = new Task("Test Task", "Test Description");
        
        assertEquals("Test Task", task.getTitle());
        assertEquals("Test Description", task.getDescription());
        assertEquals(TaskStatus.TODO, task.getStatus());
        assertEquals(TaskPriority.MEDIUM, task.getPriority());
        assertNotNull(task.getCreatedAt());
        assertNotNull(task.getUpdatedAt());
    }
    
    @Test
    void testTaskWithStatus() {
        Task task = new Task("Task", "Description", TaskStatus.IN_PROGRESS, TaskPriority.HIGH);
        
        assertEquals(TaskStatus.IN_PROGRESS, task.getStatus());
        assertEquals(TaskPriority.HIGH, task.getPriority());
    }
    
    @Test
    void testMoveToStatus() {
        Task task = new Task("Test Task", "Description");
        assertEquals(TaskStatus.TODO, task.getStatus());
        
        task.moveToStatus(TaskStatus.DONE);
        assertEquals(TaskStatus.DONE, task.getStatus());
    }
    
    @Test
    void testTaskStatusFromString() {
        assertEquals(TaskStatus.TODO, TaskStatus.fromString("todo"));
        assertEquals(TaskStatus.TODO, TaskStatus.fromString("TODO"));
        assertEquals(TaskStatus.IN_PROGRESS, TaskStatus.fromString("in_progress"));
        assertEquals(TaskStatus.DONE, TaskStatus.fromString("done"));
        assertEquals(TaskStatus.TODO, TaskStatus.fromString("invalid")); // Default
    }
    
    @Test
    void testTaskPriorityFromString() {
        assertEquals(TaskPriority.LOW, TaskPriority.fromString("low"));
        assertEquals(TaskPriority.MEDIUM, TaskPriority.fromString("medium"));
        assertEquals(TaskPriority.HIGH, TaskPriority.fromString("high"));
        assertEquals(TaskPriority.URGENT, TaskPriority.fromString("urgent"));
        assertEquals(TaskPriority.MEDIUM, TaskPriority.fromString("invalid")); // Default
    }
}

