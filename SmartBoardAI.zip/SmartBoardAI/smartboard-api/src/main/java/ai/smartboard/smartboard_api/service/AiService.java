package ai.smartboard.smartboard_api.service;

import ai.smartboard.smartboard_api.model.AIResponse;
import ai.smartboard.smartboard_api.model.TaskPriority;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class AiService {

    @Value("${python.service.url}")
    private String pythonServiceUrl;

    private final RestTemplate restTemplate;

    public AiService() {
        this.restTemplate = new RestTemplate();
    }

    public AIResponse generatePlan(String message) {
        try {
            // Call Python AI service
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("prompt", message);
            requestBody.put("max_tasks", 10);
            
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);
            
            // Call Python service at /api/projects/generate_plan
            String url = pythonServiceUrl + "/api/projects/generate_plan";
            @SuppressWarnings("unchecked")
            ResponseEntity<Map> response = restTemplate.postForEntity(url, request, Map.class);
            
            // Parse Python response into AIResponse
            @SuppressWarnings("unchecked")
            Map<String, Object> responseBody = response.getBody();
            if (responseBody != null && responseBody.containsKey("success")) {
                return parsePythonResponse(responseBody);
            }
            
            // If response is invalid, fall back to mock
            return createMockResponse(message);
            
        } catch (Exception e) {
            // Log error and fallback to mock response
            System.err.println("Error calling Python AI service: " + e.getMessage());
            return createMockResponse(message);
        }
    }
    
    private AIResponse parsePythonResponse(Map<String, Object> responseBody) {
        AIResponse aiResponse = new AIResponse();
        
        // Check if request was successful
        Boolean success = (Boolean) responseBody.get("success");
        if (success == null || !success) {
            String errorMsg = (String) responseBody.get("error_message");
            aiResponse.setMessage("I encountered an issue: " + (errorMsg != null ? errorMsg : "Unknown error"));
            aiResponse.setSuggestedTasks(new ArrayList<>());
            aiResponse.setPlan("Unable to generate plan.");
            return aiResponse;
        }
        
        // Extract tasks from Python response
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> tasksData = (List<Map<String, Object>>) responseBody.get("tasks");
        List<AIResponse.TaskSuggestion> suggestions = new ArrayList<>();
        
        if (tasksData != null) {
            for (Map<String, Object> taskData : tasksData) {
                AIResponse.TaskSuggestion suggestion = parseTaskSuggestion(taskData);
                suggestions.add(suggestion);
            }
        }
        
        aiResponse.setMessage("I've analyzed your project and created a structured plan with suggested tasks.");
        aiResponse.setSuggestedTasks(suggestions);
        aiResponse.setPlan((String) responseBody.getOrDefault("project_summary", "Project planning completed."));
        
        return aiResponse;
    }
    
    private AIResponse.TaskSuggestion parseTaskSuggestion(Map<String, Object> taskData) {
        String priorityStr = (String) taskData.getOrDefault("priority", "medium");
        TaskPriority priority;
        
        try {
            priority = TaskPriority.valueOf(priorityStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            priority = TaskPriority.MEDIUM;
        }
        
        Integer estimatedHours = null;
        Object hours = taskData.get("estimated_hours");
        if (hours != null) {
            if (hours instanceof Number) {
                estimatedHours = ((Number) hours).intValue();
            }
        }
        
        return new AIResponse.TaskSuggestion(
            (String) taskData.get("title"),
            (String) taskData.get("description"),
            priority,
            estimatedHours,
            (String) taskData.get("category")
        );
    }
    
    private AIResponse createMockResponse(String message) {
        // Fallback mock response when Python service is unavailable
        AIResponse response = new AIResponse();
        
        // Create a helpful message
        response.setMessage("I've analyzed your project and created a structured plan with suggested tasks.");
        
        // Create task suggestions
        List<AIResponse.TaskSuggestion> tasks = new ArrayList<>();
        
        if (message != null && (message.toLowerCase().contains("website") || message.toLowerCase().contains("web"))) {
            tasks.add(new AIResponse.TaskSuggestion(
                "Set up project structure", 
                "Initialize repository and basic project structure", 
                TaskPriority.HIGH, 
                8, 
                "Setup"
            ));
            tasks.add(new AIResponse.TaskSuggestion(
                "Design UI/UX", 
                "Create wireframes and design mockups", 
                TaskPriority.HIGH, 
                16, 
                "Design"
            ));
            tasks.add(new AIResponse.TaskSuggestion(
                "Implement frontend", 
                "Build responsive user interface", 
                TaskPriority.MEDIUM, 
                40, 
                "Development"
            ));
            tasks.add(new AIResponse.TaskSuggestion(
                "Database setup", 
                "Design and implement database schema", 
                TaskPriority.MEDIUM, 
                12, 
                "Backend"
            ));
        } else if (message != null && (message.toLowerCase().contains("app") || message.toLowerCase().contains("mobile"))) {
            tasks.add(new AIResponse.TaskSuggestion(
                "Market research", 
                "Analyze target audience and competitors", 
                TaskPriority.HIGH, 
                16, 
                "Research"
            ));
            tasks.add(new AIResponse.TaskSuggestion(
                "Design wireframes", 
                "Create app screens and user flows", 
                TaskPriority.HIGH, 
                20, 
                "Design"
            ));
            tasks.add(new AIResponse.TaskSuggestion(
                "Development setup", 
                "Configure development environment and tools", 
                TaskPriority.MEDIUM, 
                8, 
                "Setup"
            ));
            tasks.add(new AIResponse.TaskSuggestion(
                "Implement core features", 
                "Build main functionality", 
                TaskPriority.MEDIUM, 
                80, 
                "Development"
            ));
        } else {
            // Generic project tasks
            tasks.add(new AIResponse.TaskSuggestion(
                "Project planning", 
                "Define scope, goals, and requirements", 
                TaskPriority.HIGH, 
                8, 
                "Planning"
            ));
            tasks.add(new AIResponse.TaskSuggestion(
                "Research and analysis", 
                "Gather information and analyze requirements", 
                TaskPriority.MEDIUM, 
                16, 
                "Research"
            ));
            tasks.add(new AIResponse.TaskSuggestion(
                "Design phase", 
                "Create designs and specifications", 
                TaskPriority.MEDIUM, 
                24, 
                "Design"
            ));
            tasks.add(new AIResponse.TaskSuggestion(
                "Implementation", 
                "Build and develop the solution", 
                TaskPriority.HIGH, 
                60, 
                "Development"
            ));
        }
        
        response.setSuggestedTasks(tasks);
        response.setPlan("Based on your project description, I recommend focusing on the following areas:\n\n1. Planning and research phase\n2. Design and architecture\n3. Development and implementation\n4. Testing and deployment\n\nThis structured approach will help ensure a successful project delivery.");
        
        return response;
    }
}
