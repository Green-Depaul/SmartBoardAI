package ai.smartboard.smartboard_api.model;

public enum TaskPriority {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
    URGENT("Urgent");

    private final String displayName;

    TaskPriority(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }

    public static TaskPriority fromString(String priority) {
        if (priority == null) return MEDIUM;
        try {
            return valueOf(priority.toUpperCase());
        } catch (IllegalArgumentException e) {
            return MEDIUM;
        }
    }
}




