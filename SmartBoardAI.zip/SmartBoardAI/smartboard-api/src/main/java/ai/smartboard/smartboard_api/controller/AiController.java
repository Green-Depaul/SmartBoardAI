package ai.smartboard.smartboard_api.controller;

import ai.smartboard.smartboard_api.model.AIResponse;
import ai.smartboard.smartboard_api.service.AiService;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@CrossOrigin(origins = "*")
public class AiController {

    private final AiService aiService;

    public AiController(AiService aiService) {
        this.aiService = aiService;
    }

    @PostMapping("/generate-plan")
    public AIResponse generatePlan(@RequestBody Map<String, Object> request) {
        String message = (String) request.get("message");
        return aiService.generatePlan(message);
    }

    @GetMapping("/health")
    public Map<String, String> healthCheck() {
        return Map.of("status", "AI service is healthy");
    }
}
