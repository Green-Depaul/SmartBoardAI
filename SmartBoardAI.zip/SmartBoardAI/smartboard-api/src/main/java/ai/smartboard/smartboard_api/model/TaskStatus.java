package ai.smartboard.smartboard_api.model;

public enum TaskStatus {
    TODO("To Do"),
    IN_PROGRESS("In Progress"),
    IN_REVIEW("In Review"),
    DONE("Done");

    private final String displayName;

    TaskStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }

    public static TaskStatus fromString(String status) {
        if (status == null) return TODO;
        try {
            return valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            return TODO;
        }
    }
}




