package ai.smartboard.smartboard_api.service;

import ai.smartboard.smartboard_api.model.Board;
import ai.smartboard.smartboard_api.model.Task;
import ai.smartboard.smartboard_api.repository.BoardRepository;
import ai.smartboard.smartboard_api.repository.TaskRepository;
import ai.smartboard.smartboard_api.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Service layer for Board operations
 * Handles business logic for Kanban boards
 */
@Service
public class BoardService {
    
    private final BoardRepository boardRepository;
    private final TaskRepository taskRepository;
    private final ai.smartboard.smartboard_api.repository.UserRepository userRepository;
    
    @Autowired
    public BoardService(BoardRepository boardRepository, TaskRepository taskRepository, ai.smartboard.smartboard_api.repository.UserRepository userRepository) {
        this.boardRepository = boardRepository;
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
    }
    
    /**
     * Get all boards
     */
    public List<Board> getAllBoards() {
        List<Board> boards = boardRepository.findAll();
        // Load tasks for each board
        boards.forEach(this::loadTasksForBoard);
        return boards;
    }
    
    /**
     * Get board by ID
     */
    public Optional<Board> getBoardById(String id) {
        Optional<Board> board = boardRepository.findById(id);
        board.ifPresent(this::loadTasksForBoard);
        return board;
    }
    
    /**
     * Get boards by user ID
     */
    public List<Board> getBoardsByUserId(String userId) {
        List<Board> boards = boardRepository.findByUserId(userId);
        boards.forEach(this::loadTasksForBoard);
        return boards;
    }
    
    /**
     * Create a new board
     */
    public Board createBoard(Board board) {
        if (board.getId() == null || board.getId().isEmpty()) {
            board = new Board(board.getTitle(), board.getDescription(), board.getUserId());
        }
        return boardRepository.save(board);
    }
    
    /**
     * Update an existing board
     */
    public Optional<Board> updateBoard(String id, Board updatedBoard) {
        return boardRepository.findById(id)
                .map(existingBoard -> {
                    if (updatedBoard.getTitle() != null) {
                        existingBoard.setTitle(updatedBoard.getTitle());
                    }
                    if (updatedBoard.getDescription() != null) {
                        existingBoard.setDescription(updatedBoard.getDescription());
                    }
                    existingBoard.touch();
                    return boardRepository.save(existingBoard);
                });
    }
    
    /**
     * Delete a board and all its tasks
     */
    public boolean deleteBoard(String id) {
        if (boardRepository.existsById(id)) {
            // Delete all tasks associated with this board
            taskRepository.deleteByBoardId(id);
            // Delete the board
            return boardRepository.deleteById(id);
        }
        return false;
    }
    
    /**
     * Add a task to a board
     */
    public Optional<Task> addTaskToBoard(String boardId, Task task) {
        return boardRepository.findById(boardId)
                .map(board -> {
                    task.setBoardId(boardId);
                    Task savedTask = taskRepository.save(task);
                    board.touch();
                    boardRepository.save(board);
                    return savedTask;
                });
    }
    
    /**
     * Get all tasks for a board
     */
    public List<Task> getTasksForBoard(String boardId) {
        return taskRepository.findByBoardId(boardId);
    }
    
    /**
     * Helper method to load tasks for a board
     */
    private void loadTasksForBoard(Board board) {
        List<Task> tasks = taskRepository.findByBoardId(board.getId());
        board.setTasks(tasks);
    }
    
    /**
     * Check if board exists
     */
    public boolean boardExists(String id) {
        return boardRepository.existsById(id);
    }

    /**
     * Create a board and populate it with tasks from AI suggestions
     */
    public Optional<Board> createBoardWithTasks(String title, String description, String userId, java.util.List<ai.smartboard.smartboard_api.model.AIResponse.TaskSuggestion> suggestions) {
        // Create the board
        Board board = new Board(title, description, userId);
        board = boardRepository.save(board);
        
        // Get user for tasks (convert userId string to Long)
        Long userIdLong = Long.parseLong(userId);
        java.util.Optional<ai.smartboard.smartboard_api.model.User> userOptional = 
            userRepository.findById(userIdLong);
        
        if (userOptional.isEmpty()) {
            throw new RuntimeException("User not found with id: " + userId);
        }
        
        ai.smartboard.smartboard_api.model.User user = userOptional.get();
        
        // Create and add tasks from suggestions
        for (ai.smartboard.smartboard_api.model.AIResponse.TaskSuggestion suggestion : suggestions) {
            Task task = new Task(suggestion.getTitle(), suggestion.getDescription(), user);
            task.setPriority(suggestion.getPriority());
            task.setEstimatedHours(suggestion.getEstimatedHours());
            task.setBoardId(board.getId());
            task.setStatus(ai.smartboard.smartboard_api.model.TaskStatus.TODO);
            taskRepository.save(task);
        }
        
        // Reload board with tasks
        loadTasksForBoard(board);
        return Optional.of(boardRepository.save(board));
    }

    /**
     * Adjust project based on user request and AI suggestions
     */
    public Optional<java.util.Map<String, Object>> adjustProject(String userMessage, Object projectData) {
        try {
            System.out.println("=== DEBUG: adjustProject called ===");
            System.out.println("User message: " + userMessage);
            System.out.println("Project data type: " + projectData.getClass().getName());
            
            // Call Python AI service
            java.net.URL url = new java.net.URL("http://localhost:8081/api/projects/adjust");
            System.out.println("Calling Python service at: " + url);
            
            java.net.HttpURLConnection con = (java.net.HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setDoOutput(true);
            
            // Create request body
            java.util.Map<String, Object> requestBody = new java.util.HashMap<>();
            requestBody.put("userMessage", userMessage);
            requestBody.put("projectData", projectData);
            
            ObjectMapper objectMapper = new ObjectMapper();
            String jsonRequest;
            try (java.io.OutputStream os = con.getOutputStream()) {
                jsonRequest = objectMapper.writeValueAsString(requestBody);
                System.out.println("Request JSON: " + jsonRequest);
                byte[] input = jsonRequest.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            // Read response
            int responseCode = con.getResponseCode();
            System.out.println("Response code: " + responseCode);
            
            if (responseCode == 200) {
                java.io.BufferedReader reader = new java.io.BufferedReader(
                    new java.io.InputStreamReader(con.getInputStream(), "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = reader.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                reader.close();
                
                System.out.println("Response body: " + response.toString());
                
                // Parse JSON response
                java.util.Map<String, Object> jsonResponse = objectMapper.readValue(
                    response.toString(), 
                    java.util.Map.class
                );
                java.util.Map<String, Object> result = new java.util.HashMap<>();
                result.put("message", jsonResponse.get("message"));
                result.put("updatedTasks", jsonResponse.get("updatedTasks"));
                return Optional.of(result);
            } else {
                // Read error response
                java.io.InputStream errorStream = con.getErrorStream();
                if (errorStream != null) {
                    java.io.BufferedReader reader = new java.io.BufferedReader(
                        new java.io.InputStreamReader(errorStream, "utf-8"));
                    StringBuilder errorResponse = new StringBuilder();
                    String errorLine;
                    while ((errorLine = reader.readLine()) != null) {
                        errorResponse.append(errorLine);
                    }
                    System.out.println("Error response: " + errorResponse.toString());
                    reader.close();
                }
                
                java.util.Map<String, Object> errorResponse = new java.util.HashMap<>();
                errorResponse.put("message", "Could not process your request. Please try again.");
                errorResponse.put("updatedTasks", java.util.Collections.emptyList());
                return Optional.of(errorResponse);
            }
        } catch (Exception e) {
            System.err.println("=== ERROR in adjustProject ===");
            e.printStackTrace();
            java.util.Map<String, Object> errorResponse = new java.util.HashMap<>();
            errorResponse.put("message", "Error processing request: " + e.getMessage());
            errorResponse.put("updatedTasks", java.util.Collections.emptyList());
            return Optional.of(errorResponse);
        }
    }
}

