package ai.smartboard.smartboard_api.controller;

import ai.smartboard.smartboard_api.model.Board;
import ai.smartboard.smartboard_api.model.Task;
import ai.smartboard.smartboard_api.model.TaskStatus;
import ai.smartboard.smartboard_api.model.TaskPriority;
import ai.smartboard.smartboard_api.model.User;
import ai.smartboard.smartboard_api.service.BoardService;
import ai.smartboard.smartboard_api.service.TaskService;
import ai.smartboard.smartboard_api.repository.UserRepository;
import ai.smartboard.smartboard_api.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * REST Controller for Board operations
 * Provides endpoints for managing Kanban boards
 * Compatible with frontend expectations
 */
@RestController
@RequestMapping("/api/board")
@CrossOrigin(origins = "*") // Configure appropriately for production
public class BoardController {
    
    private final BoardService boardService;
    private final UserRepository userRepository;
    private final TaskRepository taskRepository;
    private final TaskService taskService;
    
    @Autowired
    public BoardController(BoardService boardService, UserRepository userRepository, TaskRepository taskRepository, TaskService taskService) {
        this.boardService = boardService;
        this.userRepository = userRepository;
        this.taskRepository = taskRepository;
        this.taskService = taskService;
    }
    
    /**
     * GET /api/board - Get all boards
     */
    @GetMapping
    public ResponseEntity<List<Board>> getAllBoards() {
        List<Board> boards = boardService.getAllBoards();
        return ResponseEntity.ok(boards);
    }
    
    /**
     * GET /api/board/{id} - Get board by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<Board> getBoardById(@PathVariable String id) {
        return boardService.getBoardById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    /**
     * GET /api/board/user/{userId} - Get boards by user ID
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Board>> getBoardsByUserId(@PathVariable String userId) {
        List<Board> boards = boardService.getBoardsByUserId(userId);
        return ResponseEntity.ok(boards);
    }
    
    /**
     * POST /api/board - Create a new board
     */
    @PostMapping
    public ResponseEntity<Board> createBoard(@RequestBody Board board) {
        try {
            Board createdBoard = boardService.createBoard(board);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdBoard);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }
    
    /**
     * PUT /api/board/{id} - Update a board
     */
    @PutMapping("/{id}")
    public ResponseEntity<Board> updateBoard(@PathVariable String id, @RequestBody Board board) {
        return boardService.updateBoard(id, board)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    /**
     * DELETE /api/board/{id} - Delete a board
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBoard(@PathVariable String id) {
        if (boardService.deleteBoard(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
    
    /**
     * GET /api/board/{boardId}/tasks - Get all tasks for a board
     * This endpoint matches what the frontend tests expect
     */
    @GetMapping("/{boardId}/tasks")
    public ResponseEntity<List<Task>> getTasksForBoard(@PathVariable String boardId) {
        if (!boardService.boardExists(boardId)) {
            return ResponseEntity.notFound().build();
        }
        List<Task> tasks = boardService.getTasksForBoard(boardId);
        return ResponseEntity.ok(tasks);
    }
    
    /**
     * POST /api/board/{boardId}/tasks - Add a task to a board
     */
    @PostMapping("/{boardId}/tasks")
    public ResponseEntity<Task> addTaskToBoard(@PathVariable String boardId, @RequestBody Task task) {
        return boardService.addTaskToBoard(boardId, task)
                .map(createdTask -> ResponseEntity.status(HttpStatus.CREATED).body(createdTask))
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * POST /api/board/create-from-ai - Create a board with tasks from AI suggestions
     */
    @PostMapping("/create-from-ai")
    public ResponseEntity<?> createBoardFromAI(@RequestBody CreateProjectRequest request) {
        try {
            Optional<Board> board = boardService.createBoardWithTasks(
                request.getTitle(),
                request.getDescription(),
                request.getUserId(),
                request.getSuggestions()
            );
            
            if (board.isPresent()) {
                return ResponseEntity.status(HttpStatus.CREATED).body(board.get());
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * POST /api/board/adjust - Adjust project based on AI suggestions
     */
    @PostMapping("/adjust")
    public ResponseEntity<?> adjustProject(@RequestBody AdjustProjectRequest request) {
        try {
            return boardService.adjustProject(request.getUserMessage(), request.getProjectData())
                .map(response -> ResponseEntity.ok(response))
                .orElse(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * PUT /api/board/{boardId}/tasks/bulk - Update all tasks for a board
     */
    @PutMapping("/{boardId}/tasks/bulk")
    public ResponseEntity<Map<String, String>> updateBoardTasks(@PathVariable String boardId, @RequestBody Map<String, Object> request) {
        try {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> updatedTasksData = (List<Map<String, Object>>) request.get("tasks");
            
            // Get existing board
            Optional<Board> boardOpt = boardService.getBoardById(boardId);
            if (!boardOpt.isPresent()) {
                Map<String, String> error = new java.util.HashMap<>();
                error.put("message", "Board not found");
                return ResponseEntity.notFound().build();
            }
            
            // Get the board and user
            Board board = boardOpt.get();
            User user = userRepository.findById(Long.parseLong(board.getUserId())).orElse(null);
            if (user == null) {
                Map<String, String> error = new java.util.HashMap<>();
                error.put("message", "User not found");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
            }
            
            // Get current tasks for this board
            List<Task> existingTasks = taskRepository.findByBoardId(boardId);
            
            Map<Long, Task> existingTasksMap = new java.util.HashMap<>();
            for (Task t : existingTasks) {
                existingTasksMap.put(t.getId(), t);
            }
            
            // Track which incoming tasks are present
            java.util.Set<Long> processedTaskIds = new java.util.HashSet<>();
            
            // Process each incoming task
            for (Map<String, Object> taskData : updatedTasksData) {
                try {
                    Object taskIdObj = taskData.get("id");
                    String taskIdString = taskIdObj != null ? taskIdObj.toString() : null;
                    
                    Task savedTask = null;
                
                // Check if this is an update to an existing task
                if (taskIdString != null && !taskIdString.contains("temp-") && taskIdString.matches("\\d+")) {
                    try {
                        Long taskId = Long.parseLong(taskIdString);
                        
                        // Check if task exists
                        if (existingTasksMap.containsKey(taskId)) {
                            // Update existing task
                            // Mark as processed with the existing ID
                            processedTaskIds.add(taskId);
                            
                            String title = (String) taskData.get("title");
                            String description = (String) taskData.get("description");
                            TaskPriority priority = TaskPriority.valueOf((String) taskData.get("priority"));
                            Object estimatedHoursObj = taskData.get("estimatedHours");
                            Integer estimatedHours = null;
                            if (estimatedHoursObj instanceof Number) {
                                estimatedHours = ((Number) estimatedHoursObj).intValue();
                            }
                            TaskStatus status = TaskStatus.valueOf((String) taskData.get("status"));
                            
                            // Update task details
                            taskService.updateTask(taskId, title, description, priority, estimatedHours);
                            // Update status
                            taskService.updateTaskStatus(taskId, status);
                            
                            // Get the saved task from database for tracking
                            savedTask = taskRepository.findById(taskId).orElse(null);
                        } else {
                            // Task ID doesn't exist in database (AI made up an ID)
                            // Create new task with database-generated ID
                            System.out.println("Task ID " + taskId + " doesn't exist, creating new task");
                            Task task = new Task();
                            task.setTitle((String) taskData.get("title"));
                            task.setDescription((String) taskData.get("description"));
                            task.setStatus(TaskStatus.valueOf((String) taskData.get("status")));
                            task.setPriority(TaskPriority.valueOf((String) taskData.get("priority")));
                            Object estimatedHoursObj = taskData.get("estimatedHours");
                            if (estimatedHoursObj instanceof Number) {
                                task.setEstimatedHours(((Number) estimatedHoursObj).intValue());
                            }
                            task.setUser(user);
                            task.setBoardId(boardId);
                            // Set timestamps
                            task.setCreatedAt(new java.sql.Timestamp(System.currentTimeMillis()));
                            task.setUpdatedAt(new java.sql.Timestamp(System.currentTimeMillis()));
                            
                            // addTaskToBoard already saves and returns the saved task
                            java.util.Optional<Task> savedOpt = boardService.addTaskToBoard(boardId, task);
                            if (savedOpt.isPresent()) {
                                savedTask = savedOpt.get();
                                System.out.println("Created new task with database ID: " + savedTask.getId());
                                
                                // Track the NEW database-generated ID, not the AI's fake ID
                                processedTaskIds.add(savedTask.getId());
                            } else {
                                System.out.println("ERROR: Failed to save task to board");
                            }
                        }
                    } catch (Exception e) {
                        // If parsing fails, create new task
                        System.out.println("Parsing failed, creating new task. Error: " + e.getMessage());
                        Task task = new Task();
                        task.setTitle((String) taskData.get("title"));
                        task.setDescription((String) taskData.get("description"));
                        task.setStatus(TaskStatus.valueOf((String) taskData.get("status")));
                        task.setPriority(TaskPriority.valueOf((String) taskData.get("priority")));
                        Object estimatedHoursObj = taskData.get("estimatedHours");
                        if (estimatedHoursObj instanceof Number) {
                            task.setEstimatedHours(((Number) estimatedHoursObj).intValue());
                        }
                        task.setUser(user);
                        task.setBoardId(boardId);
                        // Set timestamps
                        task.setCreatedAt(new java.sql.Timestamp(System.currentTimeMillis()));
                        task.setUpdatedAt(new java.sql.Timestamp(System.currentTimeMillis()));
                        
                        // addTaskToBoard already saves and returns the saved task
                        java.util.Optional<Task> savedOpt = boardService.addTaskToBoard(boardId, task);
                        if (savedOpt.isPresent()) {
                            savedTask = savedOpt.get();
                            System.out.println("Created new task (exception) with ID: " + savedTask.getId());
                            
                            // Track the database-generated ID
                            processedTaskIds.add(savedTask.getId());
                        } else {
                            System.out.println("ERROR: Failed to save task to board (exception)");
                        }
                    }
                } else {
                    // No valid ID (temp- or null), create new task
                    System.out.println("No valid ID or temp ID, creating new task");
                    Task task = new Task();
                    task.setTitle((String) taskData.get("title"));
                    task.setDescription((String) taskData.get("description"));
                    task.setStatus(TaskStatus.valueOf((String) taskData.get("status")));
                    task.setPriority(TaskPriority.valueOf((String) taskData.get("priority")));
                    Object estimatedHoursObj = taskData.get("estimatedHours");
                    if (estimatedHoursObj instanceof Number) {
                        task.setEstimatedHours(((Number) estimatedHoursObj).intValue());
                    }
                    task.setUser(user);
                    task.setBoardId(boardId);
                    // Set timestamps
                    task.setCreatedAt(new java.sql.Timestamp(System.currentTimeMillis()));
                    task.setUpdatedAt(new java.sql.Timestamp(System.currentTimeMillis()));
                    
                    // addTaskToBoard already saves and returns the saved task
                    java.util.Optional<Task> savedOpt = boardService.addTaskToBoard(boardId, task);
                    if (savedOpt.isPresent()) {
                        savedTask = savedOpt.get();
                        System.out.println("Created new task (temp/null) with ID: " + savedTask.getId());
                        
                        // Track the database-generated ID
                        processedTaskIds.add(savedTask.getId());
                    } else {
                        System.out.println("ERROR: Failed to save task to board (temp/null)");
                    }
                }
                } catch (Exception taskException) {
                    System.out.println("Error processing individual task: " + taskException.getMessage());
                    taskException.printStackTrace();
                    // Continue with next task
                }
            }
            
            System.out.println("Processed " + processedTaskIds.size() + " tasks. Deleting removed tasks...");
            
            // Delete tasks that are in the database but not in the incoming data
            int deletedCount = 0;
            for (Task existingTask : existingTasks) {
                if (!processedTaskIds.contains(existingTask.getId())) {
                    // This task was removed by the AI assistant
                    System.out.println("Deleting task: " + existingTask.getId() + " - " + existingTask.getTitle());
                    taskRepository.delete(existingTask);
                    deletedCount++;
                }
            }
            
            System.out.println("Deleted " + deletedCount + " removed tasks");
            System.out.println("=== BULK UPDATE SUCCESS ===");
            
            Map<String, String> response = new java.util.HashMap<>();
            response.put("message", "Tasks updated successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            System.out.println("=== ERROR IN BULK UPDATE ===");
            System.out.println("Error message: " + e.getMessage());
            e.printStackTrace();
            Map<String, String> response = new java.util.HashMap<>();
            response.put("message", "Error updating tasks: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    public static class CreateProjectRequest {
        private String title;
        private String description;
        private String userId;
        private java.util.List<ai.smartboard.smartboard_api.model.AIResponse.TaskSuggestion> suggestions;

        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public String getUserId() { return userId; }
        public void setUserId(String userId) { this.userId = userId; }
        public java.util.List<ai.smartboard.smartboard_api.model.AIResponse.TaskSuggestion> getSuggestions() { return suggestions; }
        public void setSuggestions(java.util.List<ai.smartboard.smartboard_api.model.AIResponse.TaskSuggestion> suggestions) { this.suggestions = suggestions; }
    }

    public static class AdjustProjectRequest {
        private String userMessage;
        private Object projectData;

        public String getUserMessage() { return userMessage; }
        public void setUserMessage(String userMessage) { this.userMessage = userMessage; }
        public Object getProjectData() { return projectData; }
        public void setProjectData(Object projectData) { this.projectData = projectData; }
    }
}

