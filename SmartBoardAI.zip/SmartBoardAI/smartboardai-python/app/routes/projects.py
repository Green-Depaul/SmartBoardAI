# Project Routes for SmartBoardAI
# Handles project planning and task generation endpoints

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from app.models import GenerateStepsRequest, GenerateStepsResponse, GeneratePlanRequest, GeneratePlanResponse
from app.logging_config import api_logger

router = APIRouter(prefix="/api/projects", tags=["Projects"])

# Import shared service instance
from app.services.project_service import ProjectService
project_service = ProjectService()

class AdjustProjectRequest(BaseModel):
    userMessage: str
    projectData: Dict[str, Any]

class AdjustProjectResponse(BaseModel):
    message: str
    updatedTasks: List[Dict[str, Any]]

@router.post("/generate-steps", response_model=GenerateStepsResponse)
async def generate_project_steps(req: GenerateStepsRequest):
    """Generate detailed project steps from user input with AI assistance"""
    api_logger.info(f"Project steps generation requested - user_id: {req.user_id}, project_id: {req.project_id}")
    
    try:
        result = await project_service.generate_project_steps(
            user_id=req.user_id,
            project_id=req.project_id,
            project_description=req.project_description,
            project_type=req.project_type,
            complexity=req.complexity or "medium",
            timeline=req.timeline,
            team_size=req.team_size,
            temperature=req.temperature or 0.1
        )
        
        api_logger.info(f"Project steps generation completed successfully for user {req.user_id}")
        return GenerateStepsResponse(
            message_id=result["message_id"],
            project_steps=result["project_steps"],
            total_estimated_duration=result["total_estimated_duration"],
            project_summary=result["project_summary"],
            recommendations=result["recommendations"],
            meta=result["meta"]
        )
        
    except ValueError as e:
        api_logger.error(f"Failed to parse AI response: {e}")
        raise HTTPException(status_code=502, detail=str(e))
    except Exception as e:
        api_logger.error(f"Unexpected error in generate_project_steps: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/generate_plan", response_model=GeneratePlanResponse)
async def generate_plan(request: GeneratePlanRequest):
    """
    Generate project tasks from a prompt - compatible with Java backend
    
    This endpoint accepts a project description and returns a list of actionable tasks
    that can be used by the Java backend for project planning.
    """
    api_logger.info("Task generation request received")
    
    try:
        result = await project_service.generate_tasks(
            prompt=request.prompt,
            project_type=request.project_type,
            complexity=request.complexity or "medium",
            team_size=request.team_size,
            timeline=request.timeline,
            max_tasks=request.max_tasks or 10
        )
        
        api_logger.info("Task generation completed successfully")
        return GeneratePlanResponse(
            success=result["success"],
            tasks=result["tasks"],
            total_estimated_hours=result["total_estimated_hours"],
            project_summary=result["project_summary"],
            recommendations=result["recommendations"],
            error_message=result.get("error_message")
        )
        
    except Exception as e:
        api_logger.error(f"Unexpected error in generate_plan: {e}")
        return GeneratePlanResponse(
            success=False,
            tasks=[],
            error_message="Internal server error"
        )

@router.post("/adjust")
async def adjust_project(request: AdjustProjectRequest):
    """
    Adjust project based on user request and current project state
    
    This endpoint receives user feedback and the current project state (kanban board),
    then returns adjusted tasks with AI-generated changes.
    """
    api_logger.info(f"Project adjustment request received - user: {request.userMessage[:50]}...")
    
    try:
        # Prepare context for AI
        api_logger.info(f"projectData type: {type(request.projectData)}")
        api_logger.info(f"projectData keys: {request.projectData.keys() if hasattr(request.projectData, 'keys') else 'N/A'}")
        
        tasks = request.projectData.get("tasks", [])
        user_id = request.projectData.get("userId")
        
        api_logger.info(f"Number of tasks received: {len(tasks) if tasks else 0}")
        api_logger.info(f"User ID: {user_id}")
        
        # Log first task structure if available
        if tasks and len(tasks) > 0:
            api_logger.info(f"First task sample: {tasks[0]}")
        
        # Build prompt for AI with complete task data
        prompt = f"""You are an AI assistant for a Kanban board project management tool. The user is chatting with you to modify their Kanban board.

CONTEXT:
You are inside a chat interface where the user can give you instructions to modify their Kanban board. Your task is to:
1. Understand the user's request
2. Determine which tasks should be added, removed, modified, or reordered
3. Return a complete JSON with ALL tasks that should remain on the board

USER'S CHAT REQUEST: {request.userMessage}

KANBAN BOARD RULES:
- The board has columns: TODO, IN_PROGRESS, IN_REVIEW, DONE
- Each task has: id, title, description, status, priority, estimatedHours, boardId, createdAt
- STATUS determines which column the task appears in (TODO, IN_PROGRESS, IN_REVIEW, DONE)
- If a task is not in your response, it will be DELETED from the board
- If you include a task in your response, it will appear on the board with the exact fields you provide

HOW TO HANDLE REQUESTS:
- "Move task X to in progress" → Find task X, change status to "IN_PROGRESS", keep ALL other fields identical
- "Remove task X" → DO NOT include task X in your response
- "Add a new task" → Include a new task with appropriate fields
- "Split task X into two tasks" → Remove task X, add 2 new tasks with unique IDs
- "Change priority of task X" → Find task X, change priority, keep ALL other fields identical

CURRENT KANBAN BOARD STATE (Copy ALL fields exactly unless modifying):
"""
        for task in tasks:
            prompt += f"""
Task:
{{
  "id": "{task.get('id', '')}",
  "title": "{task.get('title', '')}",
  "description": "{task.get('description', '')}",
  "status": "{task.get('status', 'TODO')}",
  "priority": "{task.get('priority', 'MEDIUM')}",
  "estimatedHours": {task.get('estimatedHours', 0)},
  "boardId": "{task.get('boardId', '')}",
  "createdAt": "{task.get('createdAt', '')}"
}}
"""
        
        prompt += """
YOUR RESPONSE MUST BE VALID JSON WITH THIS EXACT FORMAT:
{
  "message": "Brief explanation of changes made",
  "updatedTasks": [
    // Include ALL tasks that should remain on the board
    // Copy EVERY field from the original tasks
    // Only modify the fields that the user asked to change
    {"id": "...", "title": "...", "description": "...", "status": "...", "priority": "...", "estimatedHours": ..., "boardId": "...", "createdAt": "..."},
    // Add more tasks as needed
  ]
}

CRITICAL RULES:
1. Include EVERY field for each task (id, title, description, status, priority, estimatedHours, boardId, createdAt)
2. Copy original fields EXACTLY unless the user asked you to change them
3. Tasks NOT in your updatedTasks array will be DELETED from the board
4. Do NOT include tasks that should be removed
5. Use appropriate status values: "TODO", "IN_PROGRESS", "IN_REVIEW", or "DONE"
6. Keep descriptions, priorities, and estimated hours as they were unless the user wants them changed"""
        
        api_logger.info(f"Prompt preview: {prompt[:200]}...")
        
        # Call AI service
        result = await project_service.adjust_project_tasks(prompt, tasks)
        
        api_logger.info(f"AI response received: {result}")
        
        # Update tasks in Java backend
        updated_tasks = result.get("updatedTasks", [])
        if updated_tasks and len(updated_tasks) > 0:
            try:
                # Get boardId from first task
                board_id = updated_tasks[0].get('boardId') if updated_tasks else None
                if board_id:
                    # Send updated tasks to Java backend for persistence
                    import httpx
                    async with httpx.AsyncClient() as client:
                        java_url = "http://localhost:8080"
                        await client.put(
                            f"{java_url}/api/board/{board_id}/tasks/bulk",
                            json={"tasks": updated_tasks},
                            timeout=10.0
                        )
                    api_logger.info(f"Tasks saved to backend for board {board_id}")
            except Exception as e:
                api_logger.error(f"Error saving tasks to backend: {e}")
                # Continue anyway - frontend still gets the updated tasks
        
        api_logger.info("Project adjustment completed successfully")
        return AdjustProjectResponse(
            message=result.get("message", "Project adjusted successfully"),
            updatedTasks=result.get("updatedTasks", [])
        )
        
    except Exception as e:
        api_logger.error(f"Unexpected error in adjust_project: {e}", exc_info=True)
        import traceback
        api_logger.error(f"Full traceback: {traceback.format_exc()}")
        return AdjustProjectResponse(
            message="Sorry, I couldn't process your request. Please try again.",
            updatedTasks=[]
        )
