# 🚀 SmartBoardAI - Quick Start Guide

## Start the Application (3 Services)

Open **3 terminal windows** and run these commands:

### Terminal 1: Java Backend
```bash
cd SmartBoardAI/smartboard-api
./mvnw spring-boot:run
```
✅ Backend running on http://localhost:8080

### Terminal 2: Python AI Service
```bash
cd SmartBoardAI/smartboardai-python

# Activate virtual environment
source .venv/bin/activate  # Linux/Mac
# OR
.venv\Scripts\activate  # Windows

# Run service
uvicorn app.main:app --host 0.0.0.0 --port 8081
```
✅ Python service running on http://localhost:8081

**First time setup:**
```bash
# Install dependencies
pip install -r requirements.txt

# Create .env file
echo "TOGETHER_API_KEY=your_key_here" > .env
echo "JAVA_BASE_URL=http://localhost:8080" >> .env
echo "CORS_ORIGINS=http://localhost:3000" >> .env
```

### Terminal 3: Frontend
```bash
cd SmartBoardAI/smartboardai-frontend
npm install  # if first time
npm run dev
```
✅ Frontend running on http://localhost:3000

## Access the Application

Open http://localhost:3000 in your browser

## Use the App

1. **Sign Up** - Create an account
2. **Navigate to Chat** - Click on Chat
3. **Describe Your Project** - Type: "I want to build a website for my business"
4. **Get AI Tasks** - AI generates tasks using Together.ai
5. **Add to Kanban** - Click "Add to Kanban" on any task
6. **View Board** - Navigate to Kanban Board
7. **Drag & Drop** - Organize your tasks!

## Troubleshooting

### Python service won't start
- Missing API key: Create `.env` file with `TOGETHER_API_KEY`
- Install dependencies: `pip install -r requirements.txt`

### Backend errors
- Port in use: Stop other Java applications
- Check logs for error messages

### Frontend not connecting
- Check backend is running on port 8080
- Check Python service on port 8081
- Open browser DevTools (F12) for errors

## Environment Variables

### Python (.env file)
```env
TOGETHER_API_KEY=your_together_api_key
TOGETHER_MODEL=meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo
JAVA_BASE_URL=http://localhost:8080
CORS_ORIGINS=http://localhost:3000
```

## All Services Running?

Check each terminal:
- ✅ Terminal 1: "Started SmartboardApiApplication"
- ✅ Terminal 2: "Application startup complete"  
- ✅ Terminal 3: "Local: http://localhost:3000/"

All green? You're ready to go! 🎉

