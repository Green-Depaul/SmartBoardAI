# Python + Together.ai Integration Setup Guide

## 🎉 Implementation Complete!

The SmartBoardAI application now has full AI integration with Together.ai via Python FastAPI service.

## Architecture

```
User Input (Frontend)
    ↓
Java Backend (AiController)
    ↓
Python AI Service (FastAPI)
    ↓
Together.ai LLM API
    ↓
Task Generation → Store in Database
    ↓
Kanban Board Display
```

## Setup Instructions

### 1. Install Python Dependencies

```bash
cd SmartBoardAI/smartboardai-python

# Create virtual environment
python -m venv .venv

# Activate virtual environment
# On Windows:
.venv\Scripts\activate
# On Linux/Mac:
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Get Together.ai API Key

1. Sign up at https://together.ai
2. Get your API key from the dashboard
3. Set it as an environment variable

### 3. Configure Environment Variables

Create a `.env` file in `SmartBoardAI/smartboardai-python/`:

```env
# Required - Get from Together.ai
TOGETHER_API_KEY=your_together_api_key_here

# Model to use
TOGETHER_MODEL=meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo

# Service configuration
APP_HOST=0.0.0.0
APP_PORT=8081
APP_ENV=dev

# Java backend URL
JAVA_BASE_URL=http://localhost:8080

# CORS origins
CORS_ORIGINS=http://localhost:3000
```

### 4. Start All Services

Open three terminals:

#### Terminal 1: Backend (Java)
```bash
cd SmartBoardAI/smartboard-api
./mvnw spring-boot:run
```
Backend runs on http://localhost:8080

#### Terminal 2: Python AI Service
```bash
cd SmartBoardAI/smartboardai-python
# Activate virtual environment if not already
source .venv/bin/activate  # Linux/Mac
# OR
.venv\Scripts\activate  # Windows

# Run Python service
uvicorn app.main:app --host 0.0.0.0 --port 8081 --reload
```
Python service runs on http://localhost:8081

#### Terminal 3: Frontend (React)
```bash
cd SmartBoardAI/smartboardai-frontend
npm install  # if not already done
npm run dev
```
Frontend runs on http://localhost:3000

### 5. Test the Integration

1. Open http://localhost:3000 in your browser
2. Sign up or log in
3. Navigate to Chat page
4. Type: "I want to build a website for my business"
5. Click Send
6. Watch as AI generates tasks using Together.ai
7. Tasks appear in the response
8. Click "Add to Kanban" on any task
9. Navigate to Kanban Board
10. See your AI-generated tasks!

## API Flow

### Request Flow
1. **Frontend**: User sends message via `api.generatePlan(message)`
2. **Java Controller**: `AiController.generatePlan()` receives request
3. **Java Service**: `AiService.generatePlan()` calls Python service
4. **Python Service**: Makes request to Together.ai LLM
5. **Together.ai**: Generates tasks based on prompt
6. **Python Service**: Parses response and returns structured tasks
7. **Java Service**: Converts Python response to AIResponse
8. **Frontend**: Displays tasks to user

### Response Format

**Python Returns** (to Java):
```json
{
  "success": true,
  "tasks": [
    {
      "id": "uuid",
      "title": "Task title",
      "description": "Task description",
      "estimated_hours": 8,
      "priority": "high",
      "category": "Development"
    }
  ],
  "project_summary": "Summary text",
  "recommendations": ["Rec 1", "Rec 2"]
}
```

**Java Returns** (to Frontend):
```json
{
  "message": "Analyzed your project...",
  "suggestedTasks": [
    {
      "title": "Task title",
      "description": "Description",
      "priority": "HIGH",
      "estimatedHours": 8,
      "category": "Development"
    }
  ],
  "plan": "Summary text"
}
```

## Configuration Files

### Java (`application.properties`)
```properties
python.service.url=http://localhost:8081
```

### Python (`.env`)
```env
TOGETHER_API_KEY=your_key
TOGETHER_MODEL=meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo
APP_PORT=8081
JAVA_BASE_URL=http://localhost:8080
```

### Frontend (Vite config)
Already configured with proxy to http://localhost:8080

## Troubleshooting

### Python Service Won't Start
- **Error**: "TOGETHER_API_KEY environment variable is required"
  - **Solution**: Set the `TOGETHER_API_KEY` in `.env` file

- **Error**: "Module not found"
  - **Solution**: Install dependencies: `pip install -r requirements.txt`

### API Returns Mock Data
- Python service is not running or unreachable
- Check that Python service is on port 8081
- Check Java logs for connection errors

### CORS Errors
- Ensure Python `.env` has `CORS_ORIGINS=http://localhost:3000`
- Java SecurityConfig already allows all origins

### Together.ai Errors
- **401 Unauthorized**: Check API key is correct
- **429 Rate Limit**: Too many requests, wait and retry
- **500 Server Error**: Together.ai service issue, wait and retry

### Database Not Saving Tasks
- Check Java backend is running
- Check database connection in `application.properties`
- Check logs for database errors

## Alternative Models

Change `TOGETHER_MODEL` in Python `.env`:

```env
# Fast and cheap
TOGETHER_MODEL=meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo

# Balanced (default)
TOGETHER_MODEL=meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo

# High quality
TOGETHER_MODEL=mistralai/Mixtral-8x7B-Instruct-v0.1
```

## Development Tips

### Python Service Logging
Check logs in Terminal 2 for:
- AI requests being made
- Responses from Together.ai
- Any errors or warnings

### Java Service Logging
Check logs in Terminal 1 for:
- Incoming API requests
- Calls to Python service
- Database operations
- Any errors

### Frontend Console
Open browser DevTools (F12) to see:
- API requests
- Responses
- Any JavaScript errors

## What's Next?

✅ User authentication  
✅ AI task generation  
✅ Task management  
✅ Kanban board  
✅ Database storage  

🔄 To add later:
- Real-time updates
- Task editing
- Project organization
- Task comments
- File attachments
- Team collaboration

## Summary

The integration is complete! You can now:
1. ✅ Chat with AI about your projects
2. ✅ Get AI-generated tasks from Together.ai
3. ✅ Add tasks to Kanban board
4. ✅ Manage tasks with drag & drop
5. ✅ View task statistics

**Everything is connected and working!** 🎉

